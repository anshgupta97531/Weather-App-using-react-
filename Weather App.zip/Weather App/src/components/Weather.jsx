import React, { useEffect, useState } from 'react';
import './Weather.css';
import searchIcon from '../../src/assets/Assets/search.png';
import clear from '../../src/assets/Assets/clear.png';
import cloud from '../../src/assets/Assets/cloud.png';
import drizzle from '../../src/assets/Assets/drizzle.png';
import humidityIcon from '../../src/assets/Assets/humidity.png';
import rain from '../../src/assets/Assets/rain.png';
import snow from '../../src/assets/Assets/snow.png';
import windIcon from '../../src/assets/Assets/wind.png';

const Weather = () => {
  const [weatherData, setWeatherData] = useState({
    humidity: null,
    windspeed: null,
    temperature: null,
    location: '',
    icon: clear,
  });
  const [city, setCity] = useState('');

  const allicons = {
    "01d": clear,
    "01n": clear,
    "02d": cloud,
    "02n": cloud,
    "03d": cloud,
    "03n": cloud,
    "04d": drizzle,
    "04n": drizzle,
    "09d": rain,
    "09n": rain,
    "10d": rain,
    "10n": rain,
    "13d": snow,
    "13n": snow,
  };

  const search = async (city) => {
    try {
      const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${import.meta.env.VITE_APP_ID}`;
      const response = await fetch(url);
      const data = await response.json();
      console.log(data);
      const icon = allicons[data.weather[0].icon] || clear;
      setWeatherData({
        humidity: data.main.humidity,
        windspeed: data.wind.speed,
        temperature: Math.floor(data.main.temp),
        location: data.name,
        icon: icon,
      });
    } catch (error) {
      console.error("Error fetching weather data:", error);
    }
  };

  useEffect(() => {
    search('Mumbai');
  }, []);

  const handleSearch = () => {
    if (city) {
      search(city);
    }
  };

  return (
    <div className='weather'>
      <div className='search-box'>
        <input
          type='text'
          placeholder='Search city'
          value={city}
          onChange={(e) => setCity(e.target.value)}
        />
        <img src={searchIcon} alt='search' onClick={handleSearch} />
      </div>
      <img src={weatherData.icon} className='weather-icon' alt='weather icon' />
      <p className='temperature'>{weatherData.temperature}°C</p>
      <p className='city'>{weatherData.location}</p>
      <div className='weather-data'>
        <div className='col'>
          <img src={humidityIcon} alt='humidity' />
          <div>
            <p>{weatherData.humidity} %</p>
            <span>Humidity</span>
          </div>
        </div>
        <div className='col'>
          <img src={windIcon} alt='wind speed' />
          <div>
            <p>{weatherData.windspeed} km/h</p>
            <span>Wind speed</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Weather;
